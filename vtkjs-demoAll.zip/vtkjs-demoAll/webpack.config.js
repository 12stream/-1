var path = require('path');
var webpack = require('webpack');
var CopyWebpackPlugin = require("copy-webpack-plugin")
var vtkRules = require('vtk.js/Utilities/config/dependency.js').webpack.core.rules;

// 載入 *.css 與 *.module.css 檔案
var cssRules = require('vtk.js/Utilities/config/dependency.js').webpack.css.rules;

var entry = path.join(__dirname, './src/index.js');
const sourcePath = path.join(__dirname, './src');
const outputPath = path.join(__dirname, './dist');

module.exports = {
    entry,
    output: {
        path: outputPath,
        filename: 'main.js',
    },
    module: {
        rules: [
            { test: /.html$/, loader: 'html-loader' },
        ].concat(vtkRules, cssRules),
    },
    resolve: {
        modules: [
            path.resolve(__dirname, 'node_modules'),
            sourcePath,
        ],
    },
    plugins: [
        new CopyWebpackPlugin({
            patterns:[
                {
                    from: path.join(__dirname, 'node_modules', 'itk', 'WebWorkers'),
                    to: path.join(__dirname, 'dist', 'itk', 'WebWorkers')
                },
                {
                    from: path.join(__dirname, 'node_modules', 'itk', 'ImageIOs'),
                    to: path.join(__dirname, 'dist', 'itk', 'ImageIOs')
                },
                {
                    from: path.join(__dirname, 'node_modules', 'itk', 'PolyDataIOs'),
                    to: path.join(__dirname, 'dist', 'itk', 'PolyDataIOs')
                },
                {
                    from: path.join(__dirname, 'node_modules', 'itk', 'MeshIOs'),
                    to: path.join(__dirname, 'dist', 'itk', 'MeshIOs')
                }
            ]

        })
    ],
};