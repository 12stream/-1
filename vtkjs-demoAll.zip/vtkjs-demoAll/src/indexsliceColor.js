/*slice*/
import 'vtk.js/Sources/Rendering/Profiles/Volume';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HtmlDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/JSZipDataAccessHelper';

import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';

import vtkVolume from 'vtk.js/Sources/Rendering/Core/Volume';
import vtkVolumeMapper from 'vtk.js/Sources/Rendering/Core/VolumeMapper';

import controlPanel from './controlPanelMultiSliceImageMapper.html';

// 流程
// source——filter——mapper——actor——render——renderwindow——interactor。
// source（资源）——filter（筛选资源（数据处理，一个或多个输入，但只有一个输出））
// ——mapper（映射筛选后的资源）——actor（可视化映射筛选后的资源）——render——renderwindow——interactor

const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0, 255],
});
const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();
fullScreenRenderer.addController(controlPanel);

const imageActorI = vtkImageSlice.newInstance();
const imageActorJ = vtkImageSlice.newInstance();
const imageActorK = vtkImageSlice.newInstance();

renderer.addActor(imageActorI);
renderer.addActor(imageActorJ);
renderer.addActor(imageActorK);

const ctfun = vtkColorTransferFunction.newInstance();
ctfun.addRGBPoint(0, 1.0, 0, 0);//立方体的颜色，红色
ctfun.addRGBPoint(45, 1.0, 0.65, 0);//橙
ctfun.addRGBPoint(61, 1.0, 1.0, 1.0);//紫
ctfun.addRGBPoint(90, 1.0, 1.0, 0);//黄
ctfun.addRGBPoint(135, 0, 1.0, 1.0);//青
ctfun.addRGBPoint(135, 0, 1.0, 0);//绿
ctfun.addRGBPoint(180, 0, 1.0, 1.0);//青
ctfun.addRGBPoint(215, 0, 0, 1.0);//蓝
ctfun.addRGBPoint(240, 1.0, 0, 1.0);//紫
ctfun.addRGBPoint(255, 0, 0, 0);//黑
ctfun.addRGBPoint(255, 1.0, 1.0, 1.0);//白
const ofun = vtkPiecewiseFunction.newInstance();
ofun.addPoint(0.0, 0.0);
ofun.addPoint(255.0, 1.0);
imageActorI.getProperty().setRGBTransferFunction(0, ctfun);
imageActorI.getProperty().setScalarOpacity(0, ofun);
imageActorJ.getProperty().setRGBTransferFunction(0, ctfun);
imageActorJ.getProperty().setScalarOpacity(0, ofun);
imageActorK.getProperty().setRGBTransferFunction(0, ctfun);
imageActorK.getProperty().setScalarOpacity(0, ofun);
// actor.getProperty().setScalarOpacityUnitDistance(0, 10.0);//设置体积单位距离透明度的数量

const reader = vtkHttpDataSetReader.newInstance({
    fetchGzip: true,
});
reader
    .setUrl(`/data/LIDC2.vti`, { loadData: true })
    .then(() => {
        const data = reader.getOutputData();
        const imageMapperI = vtkImageMapper.newInstance();
        const imageMapperJ = vtkImageMapper.newInstance();
        const imageMapperK = vtkImageMapper.newInstance();
        imageMapperI.setInputData(data);
        imageMapperI.setISlice(47);
        imageMapperJ.setInputData(data);
        imageMapperJ.setJSlice(63);
        imageMapperK.setInputData(data);
        imageMapperK.setKSlice(70);
        // // mapper——actor
        imageActorI.setMapper(imageMapperI);
        renderer.addActor(imageActorI);
        imageActorJ.setMapper(imageMapperJ);
        renderer.addActor(imageActorJ);
        imageActorK.setMapper(imageMapperK);
        renderer.addActor(imageActorK);

        renderer.resetCamera();
        renderer.resetCameraClippingRange();
        renderWindow.render();
    })

document.querySelector('.sliceI').addEventListener('input', (e) => {
    console.log(e.target.value)
    imageActorI.getMapper().setISlice(Number(e.target.value));
    renderWindow.render();
});
document.querySelector('.sliceJ').addEventListener('input', (e) => {
    console.log(e.target.value)
    imageActorJ.getMapper().setJSlice(Number(e.target.value));
    renderWindow.render();
});
document.querySelector('.sliceK').addEventListener('input', (e) => {
    console.log(e.target.value)
    imageActorK.getMapper().setKSlice(Number(e.target.value));
    renderWindow.render();
});