// 引入 ImageJ 套件
importClass(Packages.ij.IJ);

// 使用 Bio-Formats 匯入 DICOM 影像
IJ.run("Bio-Formats Importer", "open=/path/to/image.dcm autoscale color_mode=Default rois_import=[ROI manager] view=Hyperstack stack_order=XYCZT");

// 以 Tiff 格式匯出
imp = IJ.getImage();
IJ.saveAs(imp, "Tiff", "/path/to/image.tiff");

// 關閉影像
imp.close();

// 離開 ImageJ
IJ.run("Quit");