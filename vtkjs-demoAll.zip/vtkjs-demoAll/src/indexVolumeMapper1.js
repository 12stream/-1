/*VolumeMapper*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/Volume';

import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';
import vtkVolume from 'vtk.js/Sources/Rendering/Core/Volume';
import vtkVolumeMapper from 'vtk.js/Sources/Rendering/Core/VolumeMapper';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageCroppingRegionsWidget from 'vtk.js/Sources/Interaction/Widgets/ImageCroppingRegionsWidget';
import vtkColorMaps from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction/ColorMaps';
import vtkPiecewiseGaussianWidget from 'vtk.js/Sources/Interaction/Widgets/PiecewiseGaussianWidget';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
// import vtkInteractorStyleManipulator from 'vtk.js/Sources/Interaction/Style/InteractorStyleManipulator';
import vtkMouseCameraTrackballMultiRotateManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballMultiRotateManipulator';
import vtkMouseCameraTrackballPanManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballPanManipulator';
import vtkMouseCameraTrackballRollManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballRollManipulator';
import vtkMouseCameraTrackballRotateManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballRotateManipulator';
import vtkMouseCameraTrackballZoomManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballZoomManipulator';
import vtkMouseCameraTrackballZoomToMouseManipulator from 'vtk.js/Sources/Interaction/Manipulators/MouseCameraTrackballZoomToMouseManipulator'
import vtkGestureCameraManipulator from 'vtk.js/Sources/Interaction/Manipulators/GestureCameraManipulator';

// 强制HttpDataAccessHelper加载以支持gzip解压
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';

import controlPanelVolumeMapper from './controlPanelVolumeMapper.html';
import vtkPaintFilter from "vtk.js/Sources/Filters/General/PaintFilter";
import vtkPaintWidget from "vtk.js/Sources/Widgets/Widgets3D/PaintWidget";
import vtkWidgetManager from "vtk.js/Sources/Widgets/Core/WidgetManager";

// ----------------------------------------------------------------------------
// Standard rendering code setup
// ----------------------------------------------------------------------------
const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0],
    listenWindowResize:true,
    rootContainer:document.getElementById('setRenderWindow'),
    container:document.getElementById('testD')
});//提供一个实现全屏渲染窗口的架构
const renderer = fullScreenRenderer.getRenderer();//获取渲染器对象
const renderWindow = fullScreenRenderer.getRenderWindow();//获取渲染窗口对象


renderWindow.getInteractor().setDesiredUpdateRate(15.0);//获取交互器对象期望渲染帧率,每秒15针速率进行渲染
fullScreenRenderer.addController(controlPanelVolumeMapper);//添加控制器


// ----------------------------------------------------------------------------
// 服务器没有发送.gz和压缩报头
// 需要获取真实的文件名并在本地解压它
// ----------------------------------------------------------------------------

const reader = vtkHttpDataSetReader.newInstance({ fetchGzip: true });//自定义格式,该格式由一个 JSON 元数据文件组成,例如文件.vti中所示

const actor = vtkVolume.newInstance();//体积渲染
const mapper = vtkVolumeMapper.newInstance({ sampleDistance: 1.1 });//体积映射器
mapper.setSampleDistance(1.3);//设置采样距离，数值越大，映射深度越大
actor.setMapper(mapper);//设置一个图片映射器
mapper.setInputConnection(reader.getOutputPort());//设置数据到体积映射中

// create color and opacity transfer functions
const ctfun = vtkColorTransferFunction.newInstance();//颜色传递函数
ctfun.addRGBPoint(0, 85 / 255.0, 0, 0);//添加RGB点
ctfun.addRGBPoint(95, 1.0, 1.0, 1.0);
ctfun.addRGBPoint(225, 0.66, 0.66, 0.5);
ctfun.addRGBPoint(255, 0.3, 1.0, 0.5);
const ofun = vtkPiecewiseFunction.newInstance();//分段函数
ofun.addPoint(0.0, 0.0);
ofun.addPoint(255.0, 1.0);
actor.getProperty().setRGBTransferFunction(0, ctfun);//设置RGB变换属性
actor.getProperty().setScalarOpacity(0, ofun);//设置不透明数量属性
actor.getProperty().setScalarOpacityUnitDistance(0, 3.0);//设置不透明数量的距离属性
actor.getProperty().setInterpolationTypeToLinear();//设置改写类型到线
actor.getProperty().setInterpolationTypeToFastLinear();//设置改写类型到快线
actor.getProperty().setUseGradientOpacity(0, true);//设置渐变不透明度
actor.getProperty().setGradientOpacityMinimumValue(0, 2);//设置渐变不透明度最小值
actor.getProperty().setGradientOpacityMinimumOpacity(0, 0.0);//设置渐变不透明度的最小透明度
actor.getProperty().setGradientOpacityMaximumValue(0, 20);//设置渐变不透明度最大值
actor.getProperty().setGradientOpacityMaximumOpacity(0, 1.0);//设置渐变不透明度的最大透明度
actor.getProperty().setShade(true);//设置阴影
actor.getProperty().setAmbient(0.2);//设置周围环境
actor.getProperty().setDiffuse(0.7);//设置扩散
actor.getProperty().setSpecular(0.3);//设置高光
actor.getProperty().setSpecularPower(8.0);//设置高光能量



const viewAxisInput = document.querySelector('.viewAxis');//旋转角度xyz的选项值
const imageMapper = vtkImageMapper.newInstance();//图像映射器
function setupControlPanel(data, imageMapper) {

    viewAxisInput.value = 'IJKXYZ'[imageMapper.getSlicingMode()];//获取切片模型
    viewAxisInput.addEventListener('input', (ev) => {
        const sliceMode = 'IJKXYZ'.indexOf(ev.target.value);
        imageMapper.setSlicingMode(sliceMode);
        // const sliceMode = vtkImageMapper.SlicingMode.I;//获取切片
        // const viewUp = [0, 1, 0];
        //
        // imageMapper.setSlicingMode(sliceMode);//设置切片模型
        const camPosition = renderer
            .getActiveCamera()
            .getFocalPoint()
            .map((v, idx) => (idx === sliceMode ? v + 1 : v));
        const viewUp = [0, 0, 0];
        viewUp[(sliceMode + 2) % 3] = 1;
        /*camPosition为实际数据，testData为测试数据*/
        const testData = [180,250,180]
        renderer.getActiveCamera().set({ position: testData, viewUp });//设置相机，第一个参数为位置，第二个猜测为拍摄相机的初始拍摄方向
        renderer.resetCamera();//重置相机

        renderWindow.render();//渲染窗口加载
    });
}

const widget = vtkImageCroppingRegionsWidget.newInstance();//图像裁剪区域小工具
widget.setInteractor(renderWindow.getInteractor());//设置图像裁剪的交换器；

/*颜色*/
const widget1 = vtkPiecewiseGaussianWidget.newInstance({
    numberOfBins: 256,
    size: [400, 150],
});//分段高斯小工具
widget1.updateStyle({
    backgroundColor: 'rgba(255, 255, 255, 0.6)',
    histogramColor: 'rgba(100, 100, 100, 0.5)',
    strokeColor: 'rgb(0, 0, 0)',
    activeColor: 'rgb(255, 255, 255)',
    handleColor: 'rgb(50, 150, 50)',
    buttonDisableFillColor: 'rgba(255, 255, 255, 0.5)',
    buttonDisableStrokeColor: 'rgba(0, 0, 0, 0.5)',
    buttonStrokeColor: 'rgba(0, 0, 0, 1)',
    buttonFillColor: 'rgba(255, 255, 255, 1)',
    strokeWidth: 2,
    activeStrokeWidth: 3,
    buttonStrokeWidth: 1.5,
    handleWidth: 3,
    iconSize: 20, // Can be 0 if you want to remove buttons (dblClick for (+) / rightClick for (-))
    padding: 10,
});//设置颜色器的样式
fullScreenRenderer.setResizeCallback(({ width, height }) => {
    widget1.setSize(Math.min(450, width - 10), 150);
});//设置颜色器的长宽

// Demonstrate cropping planes event update
// widget.onCroppingPlanesChanged((planes) => {
//     console.log('planes changed:', planes);
// });
let presetIndex = 1;
const globalDataRange = [0, 255];
const labelContainer = document.createElement('div');
const body = document.querySelector('body');
let intervalID = null;
/*颜色器位置设置*/
const widgetContainer = document.createElement('div');
widgetContainer.style.position = 'absolute';
widgetContainer.style.top = 'calc(10px + 1em)';
widgetContainer.style.right = '5px';
widgetContainer.style.background = 'rgba(255, 255, 255, 0.3)';
body.appendChild(widgetContainer);

/*颜色提示字体样式设置*/
labelContainer.style.position = 'absolute';
labelContainer.style.top = '5px';
labelContainer.style.right = '5px';
labelContainer.style.width = '100%';
labelContainer.style.color = 'white';
labelContainer.style.textAlign = 'center';
labelContainer.style.userSelect = 'none';
labelContainer.style.cursor = 'pointer';
body.appendChild(labelContainer);

function changePreset(delta = 1) {
    presetIndex =
        (presetIndex + delta + vtkColorMaps.rgbPresetNames.length) %
        vtkColorMaps.rgbPresetNames.length;
    ctfun.applyColorMap(
        vtkColorMaps.getPresetByName(vtkColorMaps.rgbPresetNames[presetIndex])
    );
    ctfun.setMappingRange(...globalDataRange);
    ctfun.updateRange();
    labelContainer.innerHTML = vtkColorMaps.rgbPresetNames[presetIndex];
}

/*灰度*/
const imageActorI = vtkImageSlice.newInstance();
const imageActorJ = vtkImageSlice.newInstance();
const imageActorK = vtkImageSlice.newInstance();

renderer.addActor(imageActorK);
renderer.addActor(imageActorJ);
renderer.addActor(imageActorI);
function updateColorLevel(e) {
    const colorLevel = Number(
        (e ? e.target : document.querySelector('.colorLevel')).value
    );
    imageActorI.getProperty().setColorLevel(colorLevel);
    imageActorJ.getProperty().setColorLevel(colorLevel);
    imageActorK.getProperty().setColorLevel(colorLevel);
    renderWindow.render();
}

function updateColorWindow(e) {
    const colorLevel = Number(
        (e ? e.target : document.querySelector('.colorWindow')).value
    );
    imageActorI.getProperty().setColorWindow(colorLevel);
    imageActorJ.getProperty().setColorWindow(colorLevel);
    imageActorK.getProperty().setColorWindow(colorLevel);
    renderWindow.render();
}
/*截面图开始*/
const widgetManager = vtkWidgetManager.newInstance();//工具管理器
widgetManager.setRenderer(renderer);//设置渲染
const vidgetGaintWidget = vtkPaintWidget.newInstance();//绘画小工具
widgetManager.grabFocus(vidgetGaintWidget);//抓起焦点，使得2d图不能挪动
//sliceMode为获取k截面的切面模型，renderer为渲染器对象，data为获取的数据
function setCamera(sliceMode, renderer, data) {
    console.log(sliceMode,'sliceMode')
    const ijk = [0, 0, 0];
    const position = [0, 0, 0];
    let focalPoint = [0, 0, 0];
    data.indexToWorld(ijk, focalPoint);//设置数据ijk的中心点到集中点,需要先首次初始化位置后，再进行截面切换
    ijk[sliceMode] = 1;//设置的某个界面数值为1，即为当前展示面
    data.indexToWorld(ijk, position);//设置数据ijk的中心点到集中点
    renderer.getActiveCamera().set({ focalPoint, position });//设置集中点位置
    renderer.resetCamera();//重置相机渲染
}

/*截面图结束*/
/*控制器开始*/
// const interactorStyle = vtkInteractorStyleManipulator.newInstance();//交换机样式控制
// fullScreenRenderer.getInteractor().setInteractorStyle(interactorStyle);
// const uiComponents = {};
// const manipulatorFactory = {
//     None: null,
//     Pan: vtkMouseCameraTrackballPanManipulator,
//     Zoom: vtkMouseCameraTrackballZoomManipulator,
//     Roll: vtkMouseCameraTrackballRollManipulator,
//     Rotate: vtkMouseCameraTrackballRotateManipulator,
//     MultiRotate: vtkMouseCameraTrackballMultiRotateManipulator,
//     ZoomToMouse: vtkMouseCameraTrackballZoomToMouseManipulator,
// };//不同效果用到的api
// function reassignManipulators() {
//     interactorStyle.removeAllMouseManipulators();//删除之前的样式
//     if(uiComponents['leftButton'].manipName !== 'None'){
//         const klass = manipulatorFactory[uiComponents['leftButton'].manipName];
//         const manipulator = klass.newInstance();
//         interactorStyle.addMouseManipulator(manipulator);//重新添加样式
//     }
// }
// const elt = document.querySelector('.leftButton');
// elt.addEventListener('change', (e) => {
//     uiComponents['leftButton'].manipName = e.target.value;
//     reassignManipulators();
// });
// uiComponents['leftButton'] = {
//     elt,
//     manipName: elt.value,
// };
// reassignManipulators();
/*控制器结束*/

reader.setUrl(`/data/LIDC2.vti`).then(() => {
    reader.loadData().then(() => {
        renderer.addVolume(actor);//渲染器增加体制渲染
        const interactor = renderWindow.getInteractor();
        interactor.setDesiredUpdateRate(15.0);
        renderer.resetCamera();
        renderer.getActiveCamera().zoom(1.5);
        renderer.getActiveCamera().elevation(70);
        renderer.resetCamera();


        /*界面截图设置开始*/
        const data = reader.getOutputData();

        mapper.setInputData(data);

        // setup control panel
        setupControlPanel(data, imageMapper);


        // 默认的切片方向/模式和摄像机视图
        const sliceMode = vtkImageMapper.SlicingMode.K;//获取k截面的切面模型,ijk分别表示x轴正方向，y轴正方向，z轴正方向
        imageMapper.setSlicingMode(sliceMode);//设置切面模型
        imageMapper.setSlice(0);//设置切片数
        setCamera(sliceMode, renderer, data);
        /*截面图设置结束*/
        /*颜色调试开始*/
        const dataArray = data.getPointData().getScalars();
        const dataRange = dataArray.getRange();
        globalDataRange[0] = dataRange[0];
        globalDataRange[1] = dataRange[1];

        // Update Lookup table
        changePreset();
        // Automatic switch to next preset every 5s
        intervalID = setInterval(changePreset, 5000);

        widget1.setDataArray(dataArray.getData());
        widget1.applyOpacity(ofun);

        widget1.setColorTransferFunction(ctfun);
        ctfun.onModified(() => {
            widget1.render();
            renderWindow.render();
        });
        /*颜色调试结束*/
        /*灰度调试开始*/
        const imageMapperK = vtkImageMapper.newInstance();
        imageMapperK.setInputData(data);
        imageMapperK.setKSlice(30);
        imageActorK.setMapper(imageMapperK);

        const imageMapperJ = vtkImageMapper.newInstance();
        imageMapperJ.setInputData(data);
        imageMapperJ.setJSlice(30);
        imageActorJ.setMapper(imageMapperJ);

        const imageMapperI = vtkImageMapper.newInstance();
        imageMapperI.setInputData(data);
        imageMapperI.setISlice(30);
        imageActorI.setMapper(imageMapperI);

        renderer.resetCameraClippingRange();

        // ['.colorLevel', '.colorWindow'].forEach((selector) => {
        //     document.querySelector(selector).setAttribute('max', dataRange[1]);
        //     document.querySelector(selector).setAttribute('value', dataRange[1]);
        // });
        // document
        //     .querySelector('.colorLevel')
        //     .setAttribute('value', (dataRange[0] + dataRange[1]) / 2);
        // updateColorLevel();
        // updateColorWindow();
        /*灰度调试结束*/

        renderer.resetCamera();
        renderWindow.render();

    });
});
// -----------------------------------------------------------
// Make some variables global so that you can inspect and
// modify objects in your browser's developer console:
// -----------------------------------------------------------
widget1.addGaussian(0.425, 0.5, 0.2, 0.3, 0.2);
widget1.addGaussian(0.75, 1, 0.3, 0, 0);

widget1.setContainer(widgetContainer);
widget1.bindMouseListeners();//监听鼠标移动

widget1.onAnimation((start) => {
    if (start) {
        renderWindow.getInteractor().requestAnimation(widget1);
    } else {
        renderWindow.getInteractor().cancelAnimation(widget1);
    }
});

widget1.onOpacityChange(() => {
    widget1.applyOpacity(ofun);
    if (!renderWindow.getInteractor().isAnimating()) {
        renderWindow.render();
    }
});
/*监听colorLevel和colorWindow*/
document
    .querySelector('.colorLevel')
    .addEventListener('input', updateColorLevel);
document
    .querySelector('.colorWindow')
    .addEventListener('input', updateColorWindow);

document.querySelector('.slice').addEventListener('input', (ev) => {
    console.log(ev.target.value,'ev.target.value')
    imageMapper.setSlice(Number(ev.target.value));//图像映射切片
});
global.source = reader;
global.mapper = mapper;
global.actor = actor;
global.ctfun = ctfun;
global.ofun = ofun;
global.renderer = renderer;
global.renderWindow = renderWindow;
global.widget1 = widget1;