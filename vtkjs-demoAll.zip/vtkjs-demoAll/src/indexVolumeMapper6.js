/*VolumeMapper*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/Volume';

import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';
import vtkVolume from 'vtk.js/Sources/Rendering/Core/Volume';
import vtkVolumeMapper from 'vtk.js/Sources/Rendering/Core/VolumeMapper';
import vtkLookupTable from 'vtk.js/Sources/Common/Core/LookupTable';
import vtkScalarBarActor from 'vtk.js/Sources/Rendering/Core/ScalarBarActor';
import vtkScalarsToColors from 'vtk.js/Sources/Common/Core/ScalarsToColors';

// Force the loading of HttpDataAccessHelper to support gzip decompression
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';

import controlPanel from './controller.html';
import vtkMatrixBuilder from "vtk.js/Sources/Common/Core/MatrixBuilder";

// ----------------------------------------------------------------------------
// Standard rendering code setup
// ----------------------------------------------------------------------------

const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0],
});
const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();

fullScreenRenderer.addController(controlPanel);

// ----------------------------------------------------------------------------
// Example code
// ----------------------------------------------------------------------------
// Server is not sending the .gz and with the compress header
// Need to fetch the true file name and uncompress it locally
// ----------------------------------------------------------------------------

const reader = vtkHttpDataSetReader.newInstance({ fetchGzip: true });

const actor = vtkVolume.newInstance();
const mapper = vtkVolumeMapper.newInstance();
mapper.setSampleDistance(1.3);
actor.setMapper(mapper);

// create color and opacity transfer functions
const lookupTable = vtkLookupTable.newInstance();
const numberColor = lookupTable.setNumberOfColors(6);
const scalarBarActor = vtkScalarBarActor.newInstance();
const scalarsToColors = vtkScalarsToColors.newInstance();
console.log(lookupTable,'lookupTable',scalarBarActor,scalarsToColors)
const ctfun = vtkColorTransferFunction.newInstance();//颜色转移函数
console.log(ctfun,'ctfun',ctfun.get())


ctfun.addRGBPoint(0, 1.0, 0, 0);//立方体的颜色，红色
// ctfun.addRGBPoint(45, 1.0, 0.65, 0);//橙
// ctfun.addRGBPoint(61, 1.0, 1.0, 1.0);//紫
// ctfun.addRGBPoint(90, 1.0, 1.0, 0);//黄
// ctfun.addRGBPoint(135, 0, 1.0, 1.0);//青
// ctfun.addRGBPoint(135, 0, 1.0, 0);//绿
// ctfun.addRGBPoint(180, 0, 1.0, 1.0);//青
// ctfun.addRGBPoint(215, 0, 0, 1.0);//蓝
// ctfun.addRGBPoint(240, 1.0, 0, 1.0);//紫
// ctfun.addRGBPoint(255, 0, 0, 0);//黑
// ctfun.addRGBPoint(255, 1.0, 1.0, 1.0);//白
// ctfun.addRGBPoint(45, 0, 0, 0);
// ctfun.addRGBPoint(95, 1.0, 1.0, 1.0);
// ctfun.addRGBPoint(95, 1.0, 1.0, 0);
// ctfun.addRGBPoint(135, 1.0, 1.0, 1.0);
// ctfun.addRGBPoint(180, 1.0, 0, 1.0);
// ctfun.addRGBPoint(255, 0, 1.0, 0);
// ctfun.addRGBPoint(225, 0.66, 0.66, 0.5);
// ctfun.addRGBPoint(255, 0.3, 1.0, 0.5);
const ofun = vtkPiecewiseFunction.newInstance();//分段
ofun.addPoint(0.0, 0.0);//分段点
// ofun.addPoint(160.0, 0.5);//分段点
ofun.addPoint(255.0, 1);//分段点
actor.getProperty().setRGBTransferFunction(0, ctfun);//设置rgb转移到体积上来
actor.getProperty().setScalarOpacity( 0,ofun);//设置体积透明度的数量
actor.getProperty().setScalarOpacityUnitDistance(0, 10.0);//设置体积单位距离透明度的数量
actor.getProperty().setInterpolationTypeToLinear();
actor.getProperty().setUseGradientOpacity(0, true);
actor.getProperty().setGradientOpacityMinimumValue(0, 2);
actor.getProperty().setGradientOpacityMinimumOpacity(0, 0.0);
actor.getProperty().setGradientOpacityMaximumValue(0, 20);
actor.getProperty().setGradientOpacityMaximumOpacity(0, 1.0);
actor.getProperty().setShade(true);
actor.getProperty().setAmbient(0.2);
actor.getProperty().setDiffuse(0.7);
actor.getProperty().setSpecular(0.3);
actor.getProperty().setSpecularPower(8.0);
var domX = Number(document.querySelector('#colorX').value);
var domR = Number(document.querySelector('#colorR').value);
var domG = Number(document.querySelector('#colorG').value);
var domB = Number(document.querySelector('#colorB').value);
document.querySelector('#colorX').addEventListener('input', (e) => {
    domX = Number(e.target.value);
    ctfun.addRGBPoint(domX, domR, domG, domB);//立方体的颜色
});
document.querySelector('#colorR').addEventListener('input', (e) => {
    domR = Number(e.target.value);
    ctfun.addRGBPoint(domX, domR, domG, domB);//立方体的颜色
});
document.querySelector('#colorG').addEventListener('input', (e) => {
    domG = Number(e.target.value);
    ctfun.addRGBPoint(domX, domR, domG, domB);//立方体的颜色
});
document.querySelector('#colorB').addEventListener('input', (e) => {
    domB = Number(e.target.value);
    ctfun.addRGBPoint(domX, domR, domG, domB);//立方体的颜色
});

document.getElementById("open").onclick = function(){
    console.log(domX,domR,domG,domB)
    actor.getProperty().setRGBTransferFunction(0, ctfun);
    renderer.resetCamera();
    renderWindow.render();
}


mapper.setInputConnection(reader.getOutputPort());

reader.setUrl(`https://kitware.github.io/vtk-js-datasets/data/vti/LIDCFull.vti`).then(() => {
    reader.loadData().then(() => {
        renderer.addVolume(actor);
        const interactor = renderWindow.getInteractor();
        // const actor1 = vtkActor.newInstance();
        // actor1.getProperty().setColor(1.0,0.0,0.0);
        interactor.setDesiredUpdateRate(15.0);
        renderer.resetCamera();
        renderer.getActiveCamera().zoom(1.5);
        renderer.getActiveCamera().elevation(70);
        renderer.resetCamera();
        renderWindow.render();
    });
});

// TEST PARALLEL ==============

let isParallel = false;
const button = document.querySelector('.text');

function toggleParallel() {
    isParallel = !isParallel;

    renderer.getActiveCamera().setParallelProjection(isParallel);

    button.innerText = `(${isParallel ? 'on' : 'off'})`;
    renderWindow.render();
}

// -----------------------------------------------------------
// Make some variables global so that you can inspect and
// modify objects in your browser's developer console:
// -----------------------------------------------------------

global.source = reader;
global.mapper = mapper;
global.actor = actor;
global.ctfun = ctfun;
global.ofun = ofun;
global.renderer = renderer;
global.renderWindow = renderWindow;
global.toggleParallel = toggleParallel;