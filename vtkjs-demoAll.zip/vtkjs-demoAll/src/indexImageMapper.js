//ImageMapper
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/All';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkWidgetManager from 'vtk.js/Sources/Widgets/Core/WidgetManager';
import vtkPaintWidget from 'vtk.js/Sources/Widgets/Widgets3D/PaintWidget';
import vtkInteractorStyleImage from 'vtk.js/Sources/Interaction/Style/InteractorStyleImage';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
import vtkPaintFilter from 'vtk.js/Sources/Filters/General/PaintFilter';
import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';

// 强制HttpDataAccessHelper加载以支持gzip解压
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';

import { ViewTypes } from 'vtk.js/Sources/Widgets/Core/WidgetManager/Constants';

import controlPanel from './controlPanelSlice.html';
// scene
const scene = {};

scene.fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    rootContainer: document.body,
    background: [0.1, 0.1, 0.1],
});// 提供一个实现全屏渲染窗口的架构

scene.renderer = scene.fullScreenRenderer.getRenderer();//获取渲染器对象
scene.renderWindow = scene.fullScreenRenderer.getRenderWindow();//获取渲染窗口对象

scene.camera = scene.renderer.getActiveCamera();//获取动态照相机
scene.camera.setParallelProjection(true);//设置共同投影，不会随窗口变动而变动

scene.fullScreenRenderer.addController(controlPanel); //添加控制器

//sliceMode为获取k截面的切面模型，renderer为渲染器对象，data为获取的数据
function setCamera(sliceMode, renderer, data) {
    console.log(sliceMode,'sliceMode')
    const ijk = [0, 0, 0];
    const position = [0, 0, 0];
    let focalPoint = [0, 0, 0];
    data.indexToWorld(ijk, focalPoint);//设置数据ijk的中心点到集中点,需要先首次初始化位置后，再进行截面切换
    ijk[sliceMode] = 1;//设置的某个界面数值为1，即为当前展示面
    data.indexToWorld(ijk, position);//设置数据ijk的中心点到集中点
    renderer.getActiveCamera().set({ focalPoint, position });//设置集中点位置
    renderer.resetCamera();//重置相机渲染
}

scene.widgetManager = vtkWidgetManager.newInstance();//工具管理器
scene.widgetManager.setRenderer(scene.renderer);//设置渲染

// Widgets
const widgets = {};
widgets.paintWidget = vtkPaintWidget.newInstance();//绘画小工具

scene.paintHandle = scene.widgetManager.addWidget(
    widgets.paintWidget,//绘图工具
);//增加小器件

scene.widgetManager.grabFocus(widgets.paintWidget);//抓起焦点，使得2d图不能挪动

// Paint filter
const painter = vtkPaintFilter.newInstance();//绘图过滤器

const image = {
    imageMapper: vtkImageMapper.newInstance(),//图像映射器
    actor: vtkImageSlice.newInstance(),//图像切片
};

const labelMap = {
    imageMapper: vtkImageMapper.newInstance(),//图像映射器
    actor: vtkImageSlice.newInstance(),//图像切片
    cfun: vtkColorTransferFunction.newInstance(),//颜色传递函数
    ofun: vtkPiecewiseFunction.newInstance(),//分段函数
};

// 背景图像管道
image.actor.setMapper(image.imageMapper);//设置图像映射器，相当于把3d图映射到2d图里面

// labelmap管道
labelMap.actor.setMapper(labelMap.imageMapper);//设置图像映射器
labelMap.imageMapper.setInputConnection(painter.getOutputPort());//设置绘图功能的连接

labelMap.actor.getProperty().setOpacity(0.5);//设置透明度

const reader = vtkHttpDataSetReader.newInstance({ fetchGzip: true });//自定义格式,该格式由一个 JSON 元数据文件组成,例如文件.vti中所示
reader
    .setUrl(`/data/LIDC2.vti`, { loadData: true })
    .then(() => {
        const data = reader.getOutputData();//获取数据
        image.data = data;

        // set input data
        image.imageMapper.setInputData(data);//设置输入的数据

        // add actors to renderers
        scene.renderer.addViewProp(image.actor);//增加图像切片的视图属性
        scene.renderer.addViewProp(labelMap.actor);//增加图像切片的视图属性

        // update paint filter
        painter.setBackgroundImage(image.data);//设置图片的背景颜色
        // 不要设置为0，因为那是我们PWF中的空标签颜色
        painter.setLabel(1);//设置标签

        // 默认的切片方向/模式和摄像机视图
        const sliceMode = vtkImageMapper.SlicingMode.K;//获取k截面的切面模型,ijk分别表示x轴正方向，y轴正方向，z轴正方向
        image.imageMapper.setSlicingMode(sliceMode);//设置切面模型
        image.imageMapper.setSlice(0);//设置切片数
        // painter.setSlicingMode(sliceMode);//设置切片模型

        // set 2D camera position
        setCamera(sliceMode, scene.renderer, image.data);
    });

document.querySelector('.slice').addEventListener('input', (ev) => {
    console.log(ev.target.value,'ev.target.value')
    image.imageMapper.setSlice(Number(ev.target.value));//图像映射切片
});

document.querySelector('.axis').addEventListener('input', (ev) => {
    const sliceMode = 'IJKXYZ'.indexOf(ev.target.value) % 3;
    image.imageMapper.setSlicingMode(sliceMode);
    // painter.setSlicingMode(sliceMode);

    const direction = [0, 0, 0];
    direction[sliceMode] = 1;
    scene.paintHandle.getWidgetState().getHandle().setDirection(direction);//设置方向

    setCamera(sliceMode, scene.renderer, image.data);
    scene.renderWindow.render();
});
