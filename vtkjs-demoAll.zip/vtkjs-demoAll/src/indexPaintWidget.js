/*PaintWidget*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/All';

import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkWidgetManager from 'vtk.js/Sources/Widgets/Core/WidgetManager';
import vtkPaintWidget from 'vtk.js/Sources/Widgets/Widgets3D/PaintWidget';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
import vtkPaintFilter from 'vtk.js/Sources/Filters/General/PaintFilter';
import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';

// Force the loading of HttpDataAccessHelper to support gzip decompression
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';

import { ViewTypes } from 'vtk.js/Sources/Widgets/Core/WidgetManager/Constants';
import vtkVolume from "vtk.js/Sources/Rendering/Core/Volume";
import vtkVolumeMapper from "vtk.js/Sources/Rendering/Core/VolumeMapper";

// ----------------------------------------------------------------------------
// Standard rendering code setup
// ----------------------------------------------------------------------------

// scene
const scene = {};

// Widgets
const widgets = {};
['contentAll','contentX','contentY','contentZ'].forEach((selector) => {
    scene['fullScreenRenderer'+selector] = vtkFullScreenRenderWindow.newInstance({
        rootContainer:document.getElementById('setRenderWindow'),
        container:document.getElementById(selector),
        background: [0.1, 0.1, 0.1],
    });//提供一个实现全屏渲染窗口的架构

    scene['renderer'+selector] = scene['fullScreenRenderer'+selector].getRenderer();//获取渲染器对象
    scene['renderWindow'+selector] = scene['fullScreenRenderer'+selector].getRenderWindow();//获取渲染窗口对象

    // ----------------------------------------------------------------------------
    // 部件管理器和vtkPaintFilter
    // ----------------------------------------------------------------------------

    scene['widgetManager'+selector] = vtkWidgetManager.newInstance();//工具管理器
    scene['widgetManager'+selector].setRenderer(scene['renderer'+selector]);//设置渲染

    widgets['paintWidget'+selector] = vtkPaintWidget.newInstance();//绘画小工具

    scene['widgetManager'+selector].addWidget(
        widgets['paintWidget'+selector],
        ViewTypes.SLICE
    );
    if(selector !== 'contentAll'){
        scene['camera'+selector] = scene['renderer'+selector].getActiveCamera();//获取动态照相机，不设置变换切面后不生效
        scene['camera'+selector].setParallelProjection(true);//设置共同投影,设置为true后不会随窗口变动而变动,并非固定
        scene['widgetManager'+selector].grabFocus(widgets['paintWidget'+selector]);//抓起焦点，使得2d图不能挪动
    }

});
// scene.apiSpecificRenderWindow = scene.fullScreenRenderer
//     .getInteractor()
//     .getView();//获取视图

function setCamera(sliceMode, renderer, renderWindow, data) {
    let ijk = [0, 0, 0];
    const position = [0, 0, 0];
    const focalPoint = [0, 0, 0];
    data.indexToWorld(ijk, focalPoint);
    ijk[sliceMode] = 1;
    data.indexToWorld(ijk, position);
    console.log(renderer.getActiveCamera(),'renderer.getActiveCamera()',renderer);
    // renderer.getActiveCamera().set({ focalPoint, position });
    renderer.resetCamera();
    renderWindow.render();
}

// Paint filter
const painter = vtkPaintFilter.newInstance();

const image = {
    imageMapper: vtkImageMapper.newInstance(),//图像映射器
    actor: vtkImageSlice.newInstance(),//图像切片
};

const labelMap = {
    imageMapper: vtkImageMapper.newInstance(),//图像映射器
    actor: vtkImageSlice.newInstance(),//图像切片
    cfun: vtkColorTransferFunction.newInstance(),//颜色传递函数
    ofun: vtkPiecewiseFunction.newInstance(),//分段函数
};

// background image pipeline
image.actor.setMapper(image.imageMapper);//设置图像映射器

// labelmap pipeline
labelMap.actor.setMapper(labelMap.imageMapper);//设置图像映射器
labelMap.imageMapper.setInputConnection(painter.getOutputPort());//把某些物体输入计算器中进行连接

// opacity is applied to entire labelmap
labelMap.actor.getProperty().setOpacity(0.5);

const reader = vtkHttpDataSetReader.newInstance({ fetchGzip: true });

/*全图开始*/
const actor = vtkVolume.newInstance();
const mapper = vtkVolumeMapper.newInstance();
mapper.setSampleDistance(1.3);
actor.setMapper(mapper);

// 创建颜色和不透明度转换函数
const ctfun = vtkColorTransferFunction.newInstance();
ctfun.addRGBPoint(0, 85 / 255.0, 0, 0);
ctfun.addRGBPoint(95, 1.0, 1.0, 1.0);
ctfun.addRGBPoint(225, 0.66, 0.66, 0.5);
ctfun.addRGBPoint(255, 0.3, 1.0, 0.5);
const ofun = vtkPiecewiseFunction.newInstance();
ofun.addPoint(0.0, 0.0);
ofun.addPoint(255.0, 1.0);
actor.getProperty().setRGBTransferFunction(0, ctfun);
actor.getProperty().setScalarOpacity(0, ofun);
actor.getProperty().setScalarOpacityUnitDistance(0, 3.0);
actor.getProperty().setInterpolationTypeToLinear();
actor.getProperty().setUseGradientOpacity(0, true);
actor.getProperty().setGradientOpacityMinimumValue(0, 2);
actor.getProperty().setGradientOpacityMinimumOpacity(0, 0.0);
actor.getProperty().setGradientOpacityMaximumValue(0, 20);
actor.getProperty().setGradientOpacityMaximumOpacity(0, 1.0);
actor.getProperty().setShade(true);
actor.getProperty().setAmbient(0.2);
actor.getProperty().setDiffuse(0.7);
actor.getProperty().setSpecular(0.3);
actor.getProperty().setSpecularPower(8.0);
mapper.setInputConnection(reader.getOutputPort())
/*全图结束*/
reader
    .setUrl(`/data/LIDC2.vti`, { loadData: true })
    .then(() => {

        const data = reader.getOutputData();
        image.data = data;

        // 输入数据集
        image.imageMapper.setInputData(data);
        ['contentAll','contentX','contentY','contentZ'].forEach((selector) => {
            // 向渲染器添加角色
            scene['renderer'+selector].addViewProp(image.actor);
            scene['renderer'+selector].addViewProp(labelMap.actor);
            if(selector === 'contentAll'){
                scene['renderer'+selector].addVolume(actor);
                const interactor = scene['renderWindow'+selector].getInteractor();
                interactor.setDesiredUpdateRate(15.0);
            }
        })


        // 更新绘画过滤器
        painter.setBackgroundImage(image.data);
        // 不要设置为0，因为那是我们PWF中的空标签颜色
        painter.setLabel(1);

        let contentType = {
            All:'contentAll',
            I:'contentX',
            J:'contentY',
            K:'contentZ'
        };
        let sliceMode = {};
        ['All','I', 'J','K'].forEach((type) => {
            // 默认的切片方向/模式和摄像机视图
            if(type !== 'All'){
                sliceMode[type] = vtkImageMapper.SlicingMode[type];
                image.imageMapper.setSlicingMode(sliceMode[type]);
                image.imageMapper.setSlice(100);
                painter.setSlicingMode(sliceMode[type]);

                setCamera(sliceMode[type], scene['renderer'+contentType[type]],scene['renderWindow'+contentType[type]], image.data);
                // scene['renderer'+contentType[type]].resetCamera();
                // scene['renderWindow'+contentType[type]].render();
            }else{
                scene['renderer'+contentType[type]].getActiveCamera().zoom(1.5);
                scene['renderer'+contentType[type]].getActiveCamera().elevation(70);
                scene['renderer'+contentType[type]].resetCamera();
                scene['renderWindow'+contentType[type]].render();

            }
        })

    });

document.querySelector('.slice').addEventListener('input', (ev) => {
    image.imageMapper.setSlice(Number(ev.target.value));
});

document.querySelector('.axis').addEventListener('input', (ev) => {
    const sliceMode = 'IJKXYZ'.indexOf(ev.target.value) % 3;
    console.log(sliceMode,'sliceMode')
    image.imageMapper.setSlicingMode(sliceMode);
    painter.setSlicingMode(sliceMode);

    setCamera(sliceMode, scene.renderer, image.data);
    scene.renderWindow.render();
});
