import axios from "axios";
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkITKHelper from 'vtk.js/Sources/Common/DataModel/ITKHelper'
import readImageDICOMFileSeries from 'itk/readImageDICOMFileSeries'
import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';
import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';
import vtkVolumeController from 'vtk.js/Sources/interaction/UI/VolumeController'
import vtkActor from "vtk.js/Sources/Rendering/Core/Actor";
import vtkMapper from "vtk.js/Sources/Rendering/Core/Mapper";

let path1 = 'http://192.168.1.253:8681/static/filedown?filename=/pacs/dcmdata/1.2.840.201306.33406797889875.3480.1131222633.1727532005/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099726/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099784.dcm'
let path2 = 'http://192.168.1.253:8681/static/filedown?filename=/pacs/dcmdata/1.2.840.201306.33406797889875.3480.1131222633.1727532005/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099726/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099727.dcm'
let path3 = 'http://192.168.1.253:8681/static/filedown?filename=/pacs/dcmdata/1.2.840.201306.33406797889875.3480.1131222633.1727532005/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099726.1061/1.3.12.2.1107.5.1.4.83251.30000017122208065712400099784.106.0.3.dcm'
let files_paths = [];
files_paths.push(path1,path2,path3);
const fetchFiles = files_paths.map((file_path, index) => {
    const path = file_path;
    return axios.get(path, { responseType: 'blob' }).then((response) => {
        const jsFile = new File([response.data], `${index}.dcm`); // `${index}.dcm` ` file_path.split('/').slice(-1)[0]`
        return jsFile;
    });
});
let imageData = null;
Promise.all(fetchFiles).then((files) => {
    readImageDICOMFileSeries(files).then(({ webWorker, image }) => {
        imageData = vtkITKHelper.convertItkToVtkImage(image);
    });
});


const view3d = document.getElementById('view3d');
const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    rootContainer: view3d,
    containerStyle: {
        height: '100%',
        overflow: 'hidden',
    },
    background: [0, 0, 0],
});
const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();
renderWindow.getInteractor().setDesiredUpdateRate(15);

const source = imageData;

const actor = vtkActor.newInstance();
// Pipeline handling
const mapper = vtkMapper.newInstance();
actor.setMapper(mapper);
mapper.setInputData(source);
// mapper.setSampleDistance(0.7);

const sampleDistance =
    0.7 *
    Math.sqrt(
        source
            .getSpacing()
            .map((v) => v * v)
            .reduce((a, b) => a + b, 0),
    );
mapper.setSampleDistance(sampleDistance);

renderer.addActor(actor);

const lookupTable = vtkColorTransferFunction.newInstance();
const piecewiseFunction = vtkPiecewiseFunction.newInstance();

// create color and opacity transfer functions
// 加了UI之后 这里的设置其实可以删除
lookupTable.addRGBPoint(200.0, 0.4, 0.2, 0.0);
lookupTable.addRGBPoint(2000.0, 1.0, 1.0, 1.0);

piecewiseFunction.addPoint(200.0, 0.0);
piecewiseFunction.addPoint(1200.0, 0.5);
piecewiseFunction.addPoint(3000.0, 0.8);

actor.getProperty().setRGBTransferFunction(0, lookupTable);
actor.getProperty().setScalarOpacity(0, piecewiseFunction);

actor.getProperty().setScalarOpacityUnitDistance(0, 4.5);
actor.getProperty().setInterpolationTypeToLinear();
actor.getProperty().setUseGradientOpacity(0, 1);
actor.getProperty().setGradientOpacityMinimumValue(0, 15);
actor.getProperty().setGradientOpacityMinimumOpacity(0, 0.0);
actor.getProperty().setGradientOpacityMaximumValue(0, 100);
actor.getProperty().setGradientOpacityMaximumOpacity(0, 1.0);
actor.getProperty().setShade(1);
actor.getProperty().setAmbient(0.2);
actor.getProperty().setDiffuse(0.7);
actor.getProperty().setSpecular(0.3);
actor.getProperty().setSpecularPower(8.0);

// Control UI
const controllerWidget = vtkVolumeController.newInstance({
    size: [400, 150],
    rescaleColorMap: true,
});
controllerWidget.setContainer(view3d);
controllerWidget.setupContent(renderWindow, actor, true);

fullScreenRenderer.setResizeCallback(({ width, height }) => {
    // 2px padding + 2x1px boder + 5px edge = 14
    if (width > 414) {
        controllerWidget.setSize(400, 150);
    } else {
        controllerWidget.setSize(width - 14, 150);
    }
    controllerWidget.render();
    fpsMonitor.update();
});

// First render
renderer.resetCamera();
renderWindow.render();