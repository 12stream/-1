/*Cone*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/Geometry';

import vtkActor from 'vtk.js/Sources/Rendering/Core/Actor';
import vtkCalculator from 'vtk.js/Sources/Filters/General/Calculator';
import vtkConeSource from 'vtk.js/Sources/Filters/Sources/ConeSource';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkMapper from 'vtk.js/Sources/Rendering/Core/Mapper';
import { AttributeTypes } from 'vtk.js/Sources/Common/DataModel/DataSetAttributes/Constants';
import { FieldDataTypes } from 'vtk.js/Sources/Common/DataModel/DataSet/Constants';

import vtkFPSMonitor from 'vtk.js/Sources/Interaction/UI/FPSMonitor';

import controlPanel from './controlPanel1.html';

// ----------------------------------------------------------------------------
// Standard rendering code setup
// ----------------------------------------------------------------------------

const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0],
});
const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();

const fpsMonitor = vtkFPSMonitor.newInstance();//帧数控制器
console.log(fpsMonitor,'fpsMonitor')
const fpsElm = fpsMonitor.getFpsMonitorContainer();
fpsElm.style.position = 'absolute';
fpsElm.style.left = '10px';
fpsElm.style.bottom = '10px';
fpsElm.style.background = 'rgba(255,255,255,0.5)';
fpsElm.style.borderRadius = '5px';

fpsMonitor.setContainer(document.querySelector('body'));//把控制器放到body中
fpsMonitor.setRenderWindow(renderWindow);//帧数控制器放置到渲染器中，不设置，会看不到帧数的变动

fullScreenRenderer.setResizeCallback(fpsMonitor.update);

// ----------------------------------------------------------------------------
// Example code
// ----------------------------------------------------------------------------
// create a filter on the fly, sort of cool, this is a random scalars
// filter we create inline, for a simple cone you would not need
// this
// ----------------------------------------------------------------------------

const coneSource = vtkConeSource.newInstance({
    center: [0, 500000, 0],
    height: 1.0,
});//锥体实例
const filter = vtkCalculator.newInstance();//计算器

filter.setInputConnection(coneSource.getOutputPort());//链接锥体到计算器
// filter.setFormulaSimple(FieldDataTypes.CELL, [], 'random', () => Math.random());
filter.setFormula({
    getArrays: (inputDataSets) => ({
        input: [],
        output: [
            {
                location: FieldDataTypes.CELL,
                name: 'Random',
                dataType: 'Float32Array',
                attribute: AttributeTypes.SCALARS,
            },
        ],
    }),
    evaluate: (arraysIn, arraysOut) => {
        const [scalars] = arraysOut.map((d) => d.getData());
        for (let i = 0; i < scalars.length; i++) {
            scalars[i] = Math.random();
        }
    },
});//计算器计算公式

const mapper = vtkMapper.newInstance();//映射器
mapper.setInputConnection(filter.getOutputPort());//计算映射链接

const actor = vtkActor.newInstance();//行为角色
actor.setMapper(mapper);//把映射后的锥体加到行为角色中
actor.setPosition(500000.0, 0.0, 0.0);
console.log(actor,'actor',actor.addTexture(),actor.getPosition());
renderer.addActor(actor);
renderer.resetCamera();
renderWindow.render();
fpsMonitor.update();

// -----------------------------------------------------------
// UI control handling
// -----------------------------------------------------------

fullScreenRenderer.addController(controlPanel);
const representationSelector = document.querySelector('.representations');
const resolutionChange = document.querySelector('.resolution');

representationSelector.addEventListener('change', (e) => {
    const newRepValue = Number(e.target.value);
    actor.getProperty().setRepresentation(newRepValue);
    renderWindow.render();
    fpsMonitor.update();
});

resolutionChange.addEventListener('input', (e) => {
    const resolution = Number(e.target.value);
    coneSource.setResolution(resolution);
    renderWindow.render();
    fpsMonitor.update();
});

// -----------------------------------------------------------
// Make some variables global so that you can inspect and
// modify objects in your browser's developer console:
// -----------------------------------------------------------

global.source = coneSource;
global.mapper = mapper;
global.actor = actor;
global.renderer = renderer;
global.renderWindow = renderWindow;