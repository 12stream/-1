
import 'vtk.js/Sources/Rendering/Profiles/Volume';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HtmlDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/JSZipDataAccessHelper';

import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
import vtkPaintFilter from "vtk.js/Sources/Filters/General/PaintFilter";
import vtkWidgetManager from "vtk.js/Sources/Widgets/Core/WidgetManager";
import {ViewTypes} from "vtk.js/Sources/Widgets/Core/WidgetManager/Constants";
import vtkPaintWidget from "vtk.js/Sources/Widgets/Widgets3D/PaintWidget";
import vtkSplineWidget from 'vtk.js/Sources/Widgets/Widgets3D/SplineWidget';

import controlPanel from './controllertestdemo.html';

const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0, 255],
});
const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();
fullScreenRenderer.addController(controlPanel);

const imageActorI = vtkImageSlice.newInstance();

renderer.addActor(imageActorI);


const painter = vtkPaintFilter.newInstance();//绘图过滤器
const paintWidget = vtkPaintWidget.newInstance();//绘画小工具
const widgetManager = vtkWidgetManager.newInstance();//工具管理器
widgetManager.setRenderer(renderer);//设置渲染
widgetManager.addWidget(
    paintWidget,//绘画工具
    ViewTypes.SLICE
);//增加绘画工具，设置后方不可动
widgetManager.grabFocus(paintWidget);//抓起焦点，使得2d图不能挪动

const splineWidget = vtkSplineWidget.newInstance({
        resetAfterPointPlacement: true,
});
const splineHandle = widgetManager.addWidget(
    splineWidget,
    ViewTypes.SLICE
);
splineHandle.setOutputBorder(true);
// setup 2D view
// scene.camera.setParallelProjection(true);
// scene.iStyle = vtkInteractorStyleImage.newInstance();
// scene.iStyle.setInteractionMode('IMAGE_SLICING');
// scene.renderWindow.getInteractor().setInteractorStyle(scene.iStyle);
// scene.fullScreenRenderer.addController(controlPanel);


const sliceMode = vtkImageMapper.SlicingMode.I;

const reader = vtkHttpDataSetReader.newInstance({
    fetchGzip: true,
});
reader
    .setUrl(`/data/headsq.vti`, { loadData: true })
    .then(() => {
        const data = reader.getOutputData();

        const imageMapperI = vtkImageMapper.newInstance();
        imageMapperI.setInputData(data);
        imageMapperI.setISlice(30);
        // mapper——actor
        imageActorI.setMapper(imageMapperI);
        // imageMapperI.setSlicingMode(sliceMode);
        // painter.setSlicingMode(sliceMode);
        const ijk = [0, 0, 0];
        const position = [0, 0, 0];
        const focalPoint = [0, 0, 0];
        data.indexToWorld(ijk, focalPoint);
        ijk[sliceMode] = 1;
        data.indexToWorld(ijk, position);
        renderer.getActiveCamera().set({ focalPoint, position });

            splineHandle.setHandleSizeInPixels(
                2 * Math.max(...data.getSpacing())
            );
            splineHandle.setFreehandMinDistance(
                4 * Math.max(...data.getSpacing())
            );
            splineHandle.updateRepresentationForRender();
            document.querySelector('.widget').addEventListener('input', (ev) => {
                    activeWidget = ev.target.value;
                    splineHandle.reset();
                    splineHandle.setVisibility(activeWidget === 'splineWidget');
                    splineHandle.updateRepresentationForRender();
            });

        renderer.resetCamera();
        renderWindow.render();
    })


function initializeHandle(handle) {
        handle.onStartInteractionEvent(() => {
                painter.startStroke();
        });
        handle.onEndInteractionEvent(() => {
                painter.endStroke();
        });
}
splineHandle.onEndInteractionEvent(() => {
        const points = splineHandle.getPoints();
        console.log(points)
        painter.paintPolygon(points);
        splineHandle.updateRepresentationForRender();
});
initializeHandle(splineHandle);