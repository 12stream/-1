/*AR*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/Geometry';

import vtkActor from 'vtk.js/Sources/Rendering/Core/Actor';
import vtkCalculator from 'vtk.js/Sources/Filters/General/Calculator';
import vtkConeSource from 'vtk.js/Sources/Filters/Sources/ConeSource';
import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkMapper from 'vtk.js/Sources/Rendering/Core/Mapper';
import { AttributeTypes } from 'vtk.js/Sources/Common/DataModel/DataSetAttributes/Constants';
import { FieldDataTypes } from 'vtk.js/Sources/Common/DataModel/DataSet/Constants';

// Force DataAccessHelper to have access to various data source
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HtmlDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/JSZipDataAccessHelper';
import vtkWidgetRepresentation from 'vtk.js/Sources/Widgets/Representations/WidgetRepresentation';
import vtkImplicitPlaneRepresentation from 'vtk.js/Sources/Widgets/Representations/ImplicitPlaneRepresentation';

import controlPanel from './AR.html';

// ----------------------------------------------------------------------------
// Standard rendering code setup
// ----------------------------------------------------------------------------

const fullScreenRenderer = vtkFullScreenRenderWindow.newInstance({
    rootContainer:document.getElementById('setRenderWindow'),
    container:document.getElementById('cursor'),
    containerStyle:{
      background:'red'
    },
    mtime:2,
    background: [0, 0, 0],
});

const renderer = fullScreenRenderer.getRenderer();
const renderWindow = fullScreenRenderer.getRenderWindow();
console.log(renderWindow,'renderWindow',renderer)

// ----------------------------------------------------------------------------
// 动态创建一个过滤器，有点酷，这是一个随机标量
// 过滤器我们创建内联，为一个简单的圆锥，你不需要
// ----------------------------------------------------------------------------

const coneSource = vtkConeSource.newInstance({ height: 10, radius: 10 });//锥体
const filter = vtkCalculator.newInstance();//计算

filter.setInputConnection(coneSource.getOutputPort());//连接锥体计算
filter.setFormula({
    getArrays: (inputDataSets) => ({
        input: [],
        output: [
            {
                location: FieldDataTypes.POINT,
                name: 'Random',
                dataType: 'Float32Array',
                attribute: AttributeTypes.SCALARS,
            },
        ],
    }),
    evaluate: (arraysIn, arraysOut) => {
        const [scalars] = arraysOut.map((d) => d.getData());
        for (let i = 0; i < scalars.length; i++) {
            scalars[i] = Math.random();
        }
    },
});

const mapper = vtkMapper.newInstance();
mapper.setInputConnection(filter.getOutputPort());//映射连接计算器

const actor = vtkActor.newInstance();
actor.setMapper(mapper);//角色中加入映射
// actor.setPosition(0.0, 0.0, -20.0);
// console.log(actor,'actor',vtkWidgetRepresentation.newInstance)
const representation = vtkImplicitPlaneRepresentation.newInstance();
const state = vtkImplicitPlaneRepresentation.generateState();
representation.setInputData(state);

representation.getActors().forEach(renderer.addActor);
fullScreenRenderer.addRepresentation(representation);
console.log(fullScreenRenderer,'fullScreenRenderer')

renderer.addActor(actor);
renderer.resetCamera();
renderer.resetCameraClippingRange();
renderWindow.render();

// -----------------------------------------------------------
// UI控件处理
// -----------------------------------------------------------

fullScreenRenderer.addController(controlPanel);
const arbutton = document.querySelector('.arbutton');
arbutton.disabled = false;

arbutton.addEventListener('click', (e) => {
    if (arbutton.textContent === 'Start AR') {
        fullScreenRenderer.setBackground([0, 0, 0]);
        arbutton.textContent = 'Exit AR';
    } else {
        fullScreenRenderer.setBackground([255, 255, 255]);
        arbutton.textContent = 'Start AR';
    }
    renderWindow.render();
});

// -----------------------------------------------------------
// 将一些变量设置为全局的，以便您可以检查和
// 在浏览器的开发控制台中修改对象:
// -----------------------------------------------------------

global.source = coneSource;
global.mapper = mapper;
// global.actor = actor;
global.renderer = renderer;
global.renderWindow = renderWindow;