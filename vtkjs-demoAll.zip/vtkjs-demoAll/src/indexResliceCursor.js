/*ResliceCursor*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/All';

import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import 'vtk.js/Sources/Rendering/Misc/RenderingAPIs';
import vtkResliceCursor from 'vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursor';
import vtkResliceCursorLineRepresentation from 'vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursorLineRepresentation';
import vtkResliceCursorWidget from 'vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursorWidget';
import vtkRenderer from 'vtk.js/Sources/Rendering/Core/Renderer';
import vtkRenderWindow from 'vtk.js/Sources/Rendering/Core/RenderWindow';
import vtkRenderWindowInteractor from 'vtk.js/Sources/Rendering/Core/RenderWindowInteractor';

// Force the loading of HttpDataAccessHelper to support gzip decompression
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';
import vtkFullScreenRenderWindow from "vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow";


const fullScreenRenderWindow = vtkFullScreenRenderWindow.newInstance({
    background: [0, 0, 0],
    container:document.getElementById('cursor')
});
const renderWindows = fullScreenRenderWindow.getRenderWindow();
const renderers = fullScreenRenderWindow.getRenderer();

const resliceCursor = vtkResliceCursor.newInstance();//重置切片的光标
resliceCursor.setXAxis([1, 0, 0])
const element = document.getElementById('cursor');
const GLWindows = renderWindows.newAPISpecificView();
renderWindows.addView(GLWindows);
const interactors = vtkRenderWindowInteractor.newInstance();
interactors.setView(GLWindows);
interactors.initialize();
interactors.bindEvents(element);
renderWindows.setInteractor(interactors);
const resliceCursorWidgets = vtkResliceCursorWidget.newInstance();
const resliceCursorRepresentations = vtkResliceCursorLineRepresentation.newInstance();
resliceCursorWidgets.setWidgetRep(resliceCursorRepresentations);


const reader = vtkHttpDataSetReader.newInstance({ fetchGzip: true });
reader.setUrl(`/data/LIDC2.vti`).then(() => {
    reader.loadData().then(() => {
        const image = reader.getOutputData();
        resliceCursor.setImage(image);
        // resliceCursor.setXAxis([1, 0, 0])
        resliceCursorRepresentations.getReslice().setInputData(image);
        resliceCursorRepresentations.getCursorAlgorithm().setResliceCursor(resliceCursor);

        resliceCursorWidgets.setInteractor(interactors);

// Z
        resliceCursorRepresentations.getCursorAlgorithm()
            .setReslicePlaneNormalToZAxis();

        resliceCursorWidgets.onInteractionEvent(() => {
            resliceCursorWidgets.render();
        });
        resliceCursorWidgets.setEnabled(true);

        renderers.resetCamera();
        renderWindows.render();
    });
});
// document
//     .querySelector('#cursor')
//     .addEventListener('mousedown', function (e){
//         console.log(e)
//     });
window.onload = function (){
    let disanceXY = new DragObj("#cursor");
    console.log(disanceXY,'resliceCursor')
}
