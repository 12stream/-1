/*MultiSliceImageMapper*/
import 'vtk.js/Sources/favicon';

// Load the rendering pieces we want to use (for both WebGL and WebGPU)
import 'vtk.js/Sources/Rendering/Profiles/Volume';

// Force DataAccessHelper to have access to various data source
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HtmlDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/HttpDataAccessHelper';
import 'vtk.js/Sources/IO/Core/DataAccessHelper/JSZipDataAccessHelper';

import vtkPiecewiseFunction from 'vtk.js/Sources/Common/DataModel/PiecewiseFunction';
import vtkVolume from 'vtk.js/Sources/Rendering/Core/Volume';
import vtkVolumeMapper from 'vtk.js/Sources/Rendering/Core/VolumeMapper';
import vtkColorTransferFunction from 'vtk.js/Sources/Rendering/Core/ColorTransferFunction';

import vtkFullScreenRenderWindow from 'vtk.js/Sources/Rendering/Misc/FullScreenRenderWindow';
import vtkHttpDataSetReader from 'vtk.js/Sources/IO/Core/HttpDataSetReader';
import vtkImageMapper from 'vtk.js/Sources/Rendering/Core/ImageMapper';
import vtkImageSlice from 'vtk.js/Sources/Rendering/Core/ImageSlice';
import vtkPaintFilter from "vtk.js/Sources/Filters/General/PaintFilter";
import vtkWidgetManager from "vtk.js/Sources/Widgets/Core/WidgetManager";
import vtkPaintWidget from "vtk.js/Sources/Widgets/Widgets3D/PaintWidget";
import {ViewTypes} from "vtk.js/Sources/Widgets/Core/WidgetManager/Constants";
import vtkColorMaps from "vtk.js/Sources/Rendering/Core/ColorTransferFunction/ColorMaps";
import vtkPiecewiseGaussianWidget from "vtk.js/Sources/Interaction/Widgets/PiecewiseGaussianWidget";
import vtkResliceCursor from "vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursor";
import vtkRenderWindowInteractor from "vtk.js/Sources/Rendering/Core/RenderWindowInteractor";
import vtkResliceCursorWidget from "vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursorWidget";
import vtkResliceCursorLineRepresentation
    from "vtk.js/Sources/Interaction/Widgets/ResliceCursor/ResliceCursorLineRepresentation";
import vtkPlane from "vtk.js/Sources/Common/DataModel/Plane";
import vtkMatrixBuilder from "vtk.js/Sources/Common/Core/MatrixBuilder";
import vtkCustomSliceRepresentationProxy from './vtk/CustomSliceRepresentationProxy';
import vtkProxyManager from 'vtk.js/Sources/Proxy/Core/ProxyManager';

let contentType = {
    All:'contentAll',
    X:'contentX',
    Y:'contentY',
    Z:'contentZ'
};
let typeMap = {
    X:'I',
    Y:'J',
    Z:'K'
};//类型转换
let sence = {};
const painter = vtkPaintFilter.newInstance();//绘图过滤器
const paintWidget = vtkPaintWidget.newInstance();//绘画小工具

console.log(ViewTypes,'ViewTypes')

/*颜色开始*/
let presetIndex = 1;
const globalDataRange = [0, 255];
const lookupTable = vtkColorTransferFunction.newInstance();//颜色传递函数
function changePreset(delta = 1) {
    presetIndex =
        (presetIndex + delta + vtkColorMaps.rgbPresetNames.length) %
        vtkColorMaps.rgbPresetNames.length;
    // console.log(vtkColorMaps,vtkColorMaps.getPresetByName(vtkColorMaps.rgbPresetNames[presetIndex]))
    // vtkColorMaps预设的映射颜色
    // vtkColorMaps.rgbPresetNames为预设好的颜色模块值,值如下
    // {
    //     "ColorSpace": "RGB",
    //     "Name": "BkBu",
    //     "NanColor": [1, 1, 0],
    //     "RGBPoints": [0, 0, 0, 0, 1, 0, 0, 1]
    // }
    /*32为黑白色*/
    lookupTable.applyColorMap(
        vtkColorMaps.getPresetByName(vtkColorMaps.rgbPresetNames[presetIndex])
    );//颜色请求映射
    // lookupTable.applyColorMap(
    //     vtkColorMaps.getPresetByName(vtkColorMaps.rgbPresetNames[presetIndex])
    // );//颜色请求映射
    lookupTable.setMappingRange(...globalDataRange);//设置的映射范围值为0-255
    lookupTable.updateRange();//更新设置好的映射值
}
let intervalID = null;
const widget = vtkPiecewiseGaussianWidget.newInstance({
    numberOfBins: 256,
    size: [400, 150],
});//分段高斯工具

const piecewiseFunction = vtkPiecewiseFunction.newInstance();//分段函数

/*颜色结束*/

/*任意切片开始*/
const clipPlane = vtkPlane.newInstance();
let clipPlanePosition = 0;
let clipPlaneRotationAngle = 0;
const clipPlane1Normal = [-1, 1, 0];
const clipPlane2Normal = [0, 0, 1];
const clipPlaneNormal = [1, -0.61, -0.38];//设置重点
const rotationNormal = [0, 1, 0];
/*任意切片结束*/

const customSliceRepresentationProxy = vtkCustomSliceRepresentationProxy.newInstance();
const proxyManager = vtkProxyManager.newInstance({ customSliceRepresentationProxy });
const viewProxy = proxyManager.createProxy('Views', 'View3D');
viewProxy.setContainer(document.getElementById("contentX"));
console.log(customSliceRepresentationProxy,'customSliceRepresentationProxy')

/*3D,x,y,z图渲染*/
['All','X','Y','Z'].forEach((type) => {
    sence['fullScreenRenderWindow' + type] = vtkFullScreenRenderWindow.newInstance({
        background: [0, 0, 0],
        rootContainer:document.getElementById('setRenderWindow'),
        container:document.getElementById(contentType[type])
    });//提供一个实现全屏渲染窗口的架构

    sence['renderWindow' + type] = sence['fullScreenRenderWindow' + type].getRenderWindow();//获取渲染窗口对象
    sence['renderer' + type] = sence['fullScreenRenderWindow' + type].getRenderer();//获取渲染器对象
    if(type !== 'All'){
        // sence['camera' + type] = sence['renderer' + type].getActiveCamera();//获取动态照相机，不设置变换切面后不生效
        // console.log(sence['camera' + type])
        // sence['camera' + type].setViewAngle(60);
        // sence['camera' + type].setParallelProjection(true);//设置共同投影,设置为true后不会随窗口变动而变动,并非固定
        sence['widgetManager' + type] = vtkWidgetManager.newInstance();//工具管理器
        sence['widgetManager' + type].setRenderer(sence['renderer' + type]);//设置渲染
        sence['widgetManager' + type].addWidget(
            paintWidget,//绘画工具
            ViewTypes.SLICE
        );//增加绘画工具，设置后方不可动
        sence['widgetManager' + type].grabFocus(paintWidget);//抓起焦点，使得2d图不能挪动

        sence['imageActor' + typeMap[type]] = vtkImageSlice.newInstance();//图像切片
        sence['renderer' + type].addActor(sence['imageActor' + typeMap[type]]);//窗口中增加图像切片,改代码增加黑白的切图
        // sence['fullScreenRenderWindow' + type].setResizeCallback(({ width, height }) => {
        //     console.log(width,height)
        //     widget.setSize(Math.min(450, width - 10), 150);
        // });//设置渲染窗口的大小回调函数，重置窗口大小
    }

});
/*滑动开始*/
/*原开始*/
const resliceCursor = vtkResliceCursor.newInstance();//重置切片的光标
// const element = document.getElementById('contentX');
// const GLWindows =  sence['renderWindowX'].newAPISpecificView();
// sence['renderWindowX'].addView(GLWindows);
const interactors = vtkRenderWindowInteractor.newInstance();
// interactors.setView(GLWindows);//这行代码会改变原来的切片展示
// interactors.initialize();
// interactors.bindEvents(element);
// sence['renderWindowX'].setInteractor(interactors);
const resliceCursorWidgets = vtkResliceCursorWidget.newInstance();
const resliceCursorRepresentations = vtkResliceCursorLineRepresentation.newInstance();
resliceCursorWidgets.setWidgetRep(resliceCursorRepresentations);
/*原结束*/
/*处理了，切片后变模糊的问题开始*/
// const resliceCursor = vtkResliceCursor.newInstance();//重置切片的光标
// const interactors = vtkRenderWindowInteractor.newInstance();
// const resliceCursorWidgets = vtkResliceCursorWidget.newInstance();
// const resliceCursorRepresentations = vtkResliceCursorLineRepresentation.newInstance();
// ['X','Y','Z'].forEach((type) => {
//     interactors.initialize();
//     interactors.bindEvents(document.getElementById('content'+type));
//     sence['renderWindow'+type].setInteractor(interactors);
//     resliceCursorWidgets.setWidgetRep(resliceCursorRepresentations);
// })
/*处理了，切片后变模糊的问题结束*/
/*滑动结束*/

//设置背景色
function updateColorAll(e) {
    const all = document.querySelector('.color_all').value;
    ['All','X','Y','Z'].forEach((type) => {
        // console.log(all.colorRgb());
        sence['fullScreenRenderWindow' + type].setBackground(all.colorRgb());
        sence['renderWindow' + type].render();
    })
}

//设置窗口的色阶，即黑白色的过度
function updateColorLevel(e) {
    const colorLevel = Number(
        (e ? e.target : document.querySelector('.colorLevel')).value
    );
    ['All','X','Y','Z'].forEach((type) => {
        if(type !== 'All'){
            sence['imageActor' + typeMap[type]].getProperty().setColorLevel(colorLevel);
            sence['renderWindow'+type].render();
        }
    })
    console.log(document.querySelector('.colorLevel').value)
}
//实体颜色的黑白色值过度
function updateColorWindow(e) {
    const colorLevel = Number(
        (e ? e.target : document.querySelector('.colorWindow')).value
    );
    ['All','X','Y','Z'].forEach((type) => {
        if(type !== 'All'){
            sence['imageActor' + typeMap[type]].getProperty().setColorWindow(colorLevel);
            sence['renderWindow'+type].render();
        }
    })
}


const reader = vtkHttpDataSetReader.newInstance({
    fetchGzip: true,
});//自定义加载数据包

/*全图开始*/
const actor = vtkVolume.newInstance();//体渲染
const mapper = vtkVolumeMapper.newInstance({ sampleDistance: 1.1 });//体渲染映射
mapper.setSampleDistance(1.3);//体渲染距离原色
actor.setMapper(mapper);

// 创建颜色和不透明度转换函数
const ctfun = vtkColorTransferFunction.newInstance(); //颜色传递函数
ctfun.addRGBPoint(0, 85 / 255.0, 0, 0);
ctfun.addRGBPoint(95, 1.0, 1.0, 1.0);
ctfun.addRGBPoint(225, 0.66, 0.66, 0.5);
ctfun.addRGBPoint(255, 0.3, 1.0, 0.5);
piecewiseFunction.addPoint(0.0, 0.0);
piecewiseFunction.addPoint(255.0, 1.0);
actor.getProperty().setRGBTransferFunction(0, ctfun);
actor.getProperty().setScalarOpacity(0, piecewiseFunction);
actor.getProperty().setScalarOpacityUnitDistance(0, 3.0);
actor.getProperty().setInterpolationTypeToLinear();
actor.getProperty().setUseGradientOpacity(0, true);
actor.getProperty().setGradientOpacityMinimumValue(0, 2);
actor.getProperty().setGradientOpacityMinimumOpacity(0, 0.0);
actor.getProperty().setGradientOpacityMaximumValue(0, 20);
actor.getProperty().setGradientOpacityMaximumOpacity(0, 1.0);
actor.getProperty().setShade(true);
actor.getProperty().setAmbient(0.2);
actor.getProperty().setDiffuse(0.7);
actor.getProperty().setSpecular(0.3);
actor.getProperty().setSpecularPower(8.0);
mapper.setInputConnection(reader.getOutputPort())
/*全图结束*/
/*设置ijk的截图*/
function setCamera(sliceMode, renderer, data) {
    const ijk = [0, 0, 0];
    const position = [0, 0, 0];
    const focalPoint = [0, 0, 0];
    data.indexToWorld(ijk, focalPoint);
    ijk[sliceMode] = 1;
    data.indexToWorld(ijk, position);
    renderer.getActiveCamera().set({ focalPoint, position });
    console.log(sence['imageActorI'].getProperty(),'sence[\'imageActor\' + typeMap[type]]')
    renderer.resetCamera();
}

/*图片切片函数*/
function showImage(imageMapper,renderWindow,sliceMode,renderer,data){
    imageMapper.setSlicingMode(sliceMode);
    painter.setSlicingMode(sliceMode);
    imageMapper.setSlice(80);

    setCamera(sliceMode, renderer, data);
    renderWindow.render();
}
reader
    .setUrl(`data/LIDC2.vti`, { loadData: true })
    .then(() => {
        sence.rendererAll.addVolume(actor);
        const interactor = sence.renderWindowAll.getInteractor();
        // interactor.setDesiredUpdateRate(15.0);

        const data = reader.getOutputData();
        const dataRange = data.getPointData().getScalars().getRange();
        const extent = data.getExtent();
        /*任意切片开始*/
        const spacing = data.getSpacing();
        const sizeX = extent[1] * spacing[0];
        const sizeY = extent[3] * spacing[1];
        const clipPlaneOrigin = [
            clipPlanePosition * clipPlaneNormal[0],
            clipPlanePosition * clipPlaneNormal[1],
            clipPlanePosition * clipPlaneNormal[2],
        ];
        clipPlane.setNormal(clipPlaneNormal);
        clipPlane.setOrigin(clipPlaneOrigin);
        mapper.addClippingPlane(clipPlane);
        interactor.setDesiredUpdateRate(15.0);
        // ['All','X','Y','Z'].forEach((type) => {
        ['All'].forEach((type) => {
            sence['renderer'+type].addVolume(actor);
            sence['renderer'+type].resetCamera();
            sence['renderer'+type].getActiveCamera().elevation(70);
            sence['renderWindow'+type].render();
        })

        let el = document.querySelector('.planePosition');
        el.setAttribute('min', -sizeY);
        el.setAttribute('max', sizeY);
        el.setAttribute('value', clipPlanePosition);

        el = document.querySelector('.planeRotation');
        el.setAttribute('min', 0);
        el.setAttribute('max', 180);
        el.setAttribute('value', clipPlaneRotationAngle);
        /*任意切片结束*/
        /*颜色调试开始*/
        const dataArray = data.getPointData().getScalars();
        // const dataRangeColor = dataArray.getRange();
        // globalDataRange[0] = dataRangeColor[0];
        // globalDataRange[1] = dataRangeColor[1];

        // Update Lookup table
        changePreset();

        // Automatic switch to next preset every 5s
        intervalID = setInterval(changePreset, 1000);

        widget.setDataArray(dataArray.getData());
        widget.applyOpacity(piecewiseFunction);

        widget.setColorTransferFunction(lookupTable);
        /*颜色调试结束*/

        ['All','X','Y','Z'].forEach((type) => {
            if(type !== 'All'){
                sence['imageMapper' + typeMap[type]] = vtkImageMapper.newInstance();
                sence['imageMapper' + typeMap[type]].setInputData(data);
                sence['imageActor' + typeMap[type]].setMapper(sence['imageMapper' + typeMap[type]]);
                sence['sliceMode' + typeMap[type]] = vtkImageMapper.SlicingMode[typeMap[type]];
                console.log(sence['imageMapper' + typeMap[type]])
                showImage(sence['imageMapper' + typeMap[type]],sence['renderWindow'+type],sence['sliceMode' + typeMap[type]],sence['renderer'+type],data);
            }else{

                lookupTable.onModified(() => {
                    widget.render();
                    sence['renderWindow'+type].render();
                });

                sence['renderer'+type].addVolume(actor);
                sence['renderer'+type].resetCamera();
                // console.log(sence['renderer'+type].getActiveCamera())
                // sence['renderer'+type].getActiveCamera().setViewAngle(60);
                // sence['renderer'+type].getActiveCamera().zoom(1.5);
                sence['renderer'+type].getActiveCamera().elevation(70);
                sence['renderer'+type].resetCamera();
                sence['renderWindow'+type].render();
            }
            // if(type === 'Y' || type === 'Z'){
            //     sence['renderer'+type].resetCamera();
            //     sence['renderer'+type].resetCameraClippingRange();
            //     sence['renderWindow'+type].render();
            // }
        })
        /*滑动开始*/
        resliceCursor.setImage(data);
        console.log(resliceCursor,'resliceCursor')
        resliceCursorRepresentations.getReslice().setInputData(data);
        resliceCursorRepresentations.getCursorAlgorithm().setResliceCursor(resliceCursor);

        resliceCursorWidgets.setInteractor(interactors);

        // Z
        resliceCursorRepresentations.getCursorAlgorithm()
            .setReslicePlaneNormalToZAxis();

        resliceCursorWidgets.onInteractionEvent(() => {
            resliceCursorWidgets.render();
        });
        resliceCursorWidgets.setEnabled(true);
        /*滑动结束*/

        customSliceRepresentationProxy.setUseColorByForColor(true);

        sence.rendererY.resetCamera();
        sence.rendererY.resetCameraClippingRange();
        sence.renderWindowY.render();
        sence.rendererZ.resetCamera();
        sence.rendererZ.resetCameraClippingRange();
        sence.renderWindowZ.render();

        ['.sliceI', '.sliceJ', '.sliceK'].forEach((selector, idx) => {
            const el = document.querySelector(selector);
            el.setAttribute('min', extent[idx * 2 + 0]);
            el.setAttribute('max', extent[idx * 2 + 1]);
            el.setAttribute('value', 30);
        });

        ['.colorLevel', '.colorWindow'].forEach((selector) => {
            document.querySelector(selector).setAttribute('max', dataRange[1]);
            document.querySelector(selector).setAttribute('value', dataRange[1]);
        });
        document
            .querySelector('.colorLevel')
            .setAttribute('value', (dataRange[0] + dataRange[1]) / 2);

        updateColorLevel();
        updateColorWindow();
    });


['X', 'Y', 'Z'].forEach((selector, idx) => {
    document.querySelector('.slice'+typeMap[selector]).addEventListener('input', (e) => {
        switch (selector){
            case 'X':
                sence['imageActor'+typeMap[selector]].getMapper().setISlice(Number(e.target.value));
                break;
            case 'Y':
                sence['imageActor'+typeMap[selector]].getMapper().setJSlice(Number(e.target.value));
                break;
            case 'Z':
                sence['imageActor'+typeMap[selector]].getMapper().setKSlice(Number(e.target.value));
                break;

        }
        sence['renderWindow'+selector].render();
    });
})

document
    .querySelector('.colorLevel')
    .addEventListener('input', updateColorLevel);
document
    .querySelector('.colorWindow')
    .addEventListener('input', updateColorWindow);
document
    .querySelector('.color_all')
    .addEventListener('input', updateColorAll);


/*封装滑动改变色阶色窗开始*/

function DragObj(selector){
    //保存节点
    this.ele = $(selector).get(0);

    //调用startDrag
    this.startDrag();
}

DragObj.prototype.startDrag = function(){

    var self = this;
    //给当前对象的节点添加mousedown事件
    $(self.ele).on({
        mousedown:function(oEvent){
            self.disX = oEvent.offsetX;
            self.disY = oEvent.offsetY;

            self.drag();
        }
    })

}
DragObj.prototype.drag = function(){
    var self = this;

    //给文档对象添加移动和结束事件
    $(document).on({
        mousemove:function(oEvent){
            self.disance = {
                X:oEvent.pageX - self.disX,
                Y:oEvent.pageY - self.disY
            }
            sence['imageActorI'].getProperty().setColorLevel(oEvent.offsetX);
            sence['imageActorI'].getProperty().setColorWindow(oEvent.offsetY);
            sence['renderWindowX'].render();
        },
        mouseup:function(){
            $(document).off('mousemove mouseup');
        }
    })
}
new DragObj('#contentX');
/*封装滑动改变色阶色窗结束*/
/*颜色开始*/
actor.setMapper(mapper);
mapper.setInputConnection(reader.getOutputPort());

actor.getProperty().setRGBTransferFunction(0, lookupTable);
actor.getProperty().setScalarOpacity(0, piecewiseFunction);
actor.getProperty().setInterpolationTypeToFastLinear();

// ----------------------------------------------------------------------------
// Default setting Piecewise function widget
// ----------------------------------------------------------------------------

widget.addGaussian(0.425, 0.5, 0.2, 0.3, 0.2);
widget.addGaussian(0.75, 1, 0.3, 0, 0);

const colorThresholdValue  = document.querySelector('.color_threshold_value');
widget.setContainer(colorThresholdValue);
widget.bindMouseListeners();
/*颜色结束*/

/*任意切片开始*/
document.querySelector('.planePosition').addEventListener('input', (e) => {
    clipPlanePosition = Number(e.target.value);
    const clipPlaneOrigin = [
        clipPlanePosition * clipPlaneNormal[0],
        clipPlanePosition * clipPlaneNormal[1],
        clipPlanePosition * clipPlaneNormal[2],
    ];
    clipPlane.setOrigin(clipPlaneOrigin);
    sence['renderWindowAll'].render();
});

document.querySelector('.planeRotation').addEventListener('input', (e) => {
    const changedDegree = Number(e.target.value) - clipPlaneRotationAngle;
    clipPlaneRotationAngle = Number(e.target.value);
    vtkMatrixBuilder
        .buildFromDegree()
        .rotate(changedDegree, rotationNormal)
        .apply(clipPlaneNormal);
    clipPlane.setNormal(clipPlaneNormal);
    sence['renderWindowAll'].render();
});
document.querySelector('.planePositionDirX').addEventListener('input', (e) => {
    const changedDegree = $('.planeRotation').val() - clipPlaneRotationAngle;
    clipPlaneNormal[0] = Number(e.target.value);
    vtkMatrixBuilder
        .buildFromDegree()
        .rotate(changedDegree, rotationNormal)
        .apply(clipPlaneNormal);
    clipPlane.setNormal(clipPlaneNormal);
    sence['renderWindowAll'].render();
});
document.querySelector('.planePositionDirY').addEventListener('input', (e) => {
    const changedDegree = $('.planeRotation').val() - clipPlaneRotationAngle;
    clipPlaneNormal[1] = Number(e.target.value);
    vtkMatrixBuilder
        .buildFromDegree()
        .rotate(changedDegree, rotationNormal)
        .apply(clipPlaneNormal);
    clipPlane.setNormal(clipPlaneNormal);
    sence['renderWindowAll'].render();
});
document.querySelector('.planePositionDirZ').addEventListener('input', (e) => {
    const changedDegree = $('.planeRotation').val() - clipPlaneRotationAngle;
    clipPlaneNormal[2] = Number(e.target.value);
    console.log(clipPlaneNormal)
    vtkMatrixBuilder
        .buildFromDegree()
        .rotate(changedDegree, rotationNormal)
        .apply(clipPlaneNormal);
    clipPlane.setNormal(clipPlaneNormal);
    sence['renderWindowAll'].render();
});
/*任意切片结束*/